#include <DHT.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

/* ----------- DHT22 Settings ----------- */
#define DHTPIN 4        // DATA pin connected to GPIO 4
#define DHTTYPE DHT22   // Using DHT22 sensor

DHT dht(DHTPIN, DHTTYPE);

/* ----------- OLED Settings ------------ */
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

void setup() {
  Serial.begin(115200);

  // Start DHT sensor
  dht.begin();

  // Start I2C (SDA = 21, SCL = 22)
  Wire.begin(21, 22);

  // Initialize OLED
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED not found");
    while (true);
  }

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
}

void loop() {
  float humidity = dht.readHumidity();
  float temperature = dht.readTemperature(); // Celsius

  display.clearDisplay();
  display.setCursor(0, 10);
  display.print("Temperature: ");
  display.print(temperature);
  display.println(" C");

  display.setCursor(0, 30);
  display.print("Humidity: ");
  display.print(humidity);
  display.println(" %");

  display.display();

  delay(2000); // update every 2 seconds
}
